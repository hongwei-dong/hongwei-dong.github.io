Two ways to run it:
1) In command lien, run the program as (the program name followed by two image names):
  DPIE src.jpg, tgt.jpg

2) modify your two image names to "src,jpg" and "tgt.jpg" .This way,the image should be converted to JPG format.

When you started the program ,you can draw a closed curve around the object using left mouse in the right image.
then move the mouse the the left image and pointing some position,the press Key "F1". 
Wait a minite,the result will be there!