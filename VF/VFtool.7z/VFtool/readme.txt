Before run the program VFdesign.exe,you should first modify the filename "VFdesign.exe=postfix" to "VFdesign.exe".

To design vector field, just move the mouse to a position (don��t click the mouse) and press a digital key such as 0 or 1 or 2 or 3 or 4 or 5 or 6 or 0 to determine the type of the design element.
You can do this several times to generate several different design elements and finally press ��F3�� key to update the vector field .

To smooth  smooth the vector field ,you can first drag a closed curve with mouse left button pressed,then just press the special key 'F2' to do smoothing.

