#include <GL/glut.h>

int view_width = 300,view_height = 300;
double left = -100,right = 100,bottom = -100,top = 100;




void renderScene(void) {

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glBegin(GL_TRIANGLES);
	glVertex2f(-60,-20);
	glVertex2f(90,-60);
	glVertex2f(10,70);
	glEnd();

	glutSwapBuffers();
}

//Called once when the application starts and again every time the window is resized by the user.
GLvoid resizeScene(GLsizei width, GLsizei height)
{
	//--------------reset the viewport--------------
  // avoid divide by zero
  if (height==0)
  {
    height=1;
  }

  // reset the viewport to the new dimensions
  glViewport(0, 0, width, height);

  // -----------set up the projection-------------------
  // select the projection matrix and clear it out
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();

  //choose the appropriate projection based on the currently toggled mode
  //gluOrtho2D(GLdouble left, GLdouble right, GLdouble bottom, GLdouble top);
  gluOrtho2D(left,right,bottom,top);

  //-----------set up the modelview--------------------
  // select modelview matrix and clear it out
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();  

} // end resizeScene()

int main(int argc, char **argv) {

	// init GLUT and create Window
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100,100);
	glutInitWindowSize(view_width,view_height);
	glutCreateWindow("Lighthouse3D - GLUT Tutorial");

	// register dispaly callbacks
	glutDisplayFunc(renderScene);
	//register reshape callbacks
	glutReshapeFunc(resizeScene);

	
	// enter GLUT event processing cycle
	glutMainLoop();
	
	return 1;
}

