Please copy this program to the root directory of driver 'D' and execut the program by double click the corre.bat.
Or you can run the program from command line. There are two functions by type the collowing keys:
1) the key 's' : to pick corresponding points
   There are three submenu with the follwing keys:
   a) 'p': to pick
   b) 'a' : to add corresponding points to corresponding points list
   c) 'u'��undo 
   

2) the key 'D':  to do 3dRegistration  